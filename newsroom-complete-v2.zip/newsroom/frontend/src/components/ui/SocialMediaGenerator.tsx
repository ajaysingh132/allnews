"use client";
import { useState } from "react";

type Platform = {
  id: string;
  name: string;
  abbr: string;
  color: string;
  bg: string;
  maxChars?: number;
  note: string;
};

type SocialPost = {
  platform: string;
  content: string;
  charCount: number;
  status: "pending" | "approved" | "editing" | "scheduled";
  scheduledAt?: string;
};

const PLATFORMS: Platform[] = [
  { id: "x_twitter",       name: "X / Twitter",   abbr: "X",  color: "text-slate-900",  bg: "bg-slate-100",   maxChars: 280,  note: "Thread में 5 tweets तक" },
  { id: "facebook",        name: "Facebook",       abbr: "FB", color: "text-blue-700",   bg: "bg-blue-50",     note: "विस्तृत, conversational" },
  { id: "instagram",       name: "Instagram",      abbr: "IG", color: "text-pink-700",   bg: "bg-pink-50",     maxChars: 2200, note: "Caption + Hashtags" },
  { id: "telegram",        name: "Telegram",       abbr: "TG", color: "text-sky-700",    bg: "bg-sky-50",      note: "Long-form okay" },
  { id: "whatsapp_channel",name: "WhatsApp",       abbr: "WA", color: "text-green-700",  bg: "bg-green-50",    note: "Concise, personal" },
  { id: "linkedin",        name: "LinkedIn",       abbr: "LI", color: "text-blue-800",   bg: "bg-blue-50",     maxChars: 3000, note: "Professional tone" },
  { id: "threads",         name: "Threads",        abbr: "TH", color: "text-purple-700", bg: "bg-purple-50",   maxChars: 500,  note: "Conversational" },
  { id: "youtube",         name: "YouTube Community", abbr: "YT", color: "text-red-700", bg: "bg-red-50",      note: "Community post" },
];

const SAMPLE_POSTS: Record<string, string> = {
  x_twitter:        "चुनावी बॉन्ड पर सुप्रीम कोर्ट के फैसले के 6 महीने बाद — क्या बदला?\n\nThread 🧵 (1/5)\n\n#ElectoralBonds #SupremeCourt #India\n\n🔗 gyanvarta.in/politics/chuna...",
  facebook:         "चुनावी बॉन्ड: 6 महीने बाद की सच्चाई\n\nफरवरी 2024 में सुप्रीम कोर्ट ने चुनावी बॉन्ड योजना को असंवैधानिक घोषित किया। 6 महीने बाद — क्या बदला, क्या नहीं बदला, और आगे क्या होगा?\n\nहमारे वरिष्ठ संपादक का विस्तृत विश्लेषण पढ़ें 👇\n\n🔗 gyanvarta.in/politics/chuna...",
  instagram:        "📊 चुनावी बॉन्ड — 6 महीने बाद\n\nसुप्रीम कोर्ट के ऐतिहासिक फैसले के बाद भारतीय चुनावी फंडिंग में क्या बदला?\n\nपूरा विश्लेषण link in bio 🔗\n\n#ChunaaviDemocracy #India #Elections #SupremeCourt #HindiNews #ज्ञानवार्ता #भारत #राजनीति",
  telegram:         "📰 **चुनावी बॉन्ड: छह महीने बाद**\n\nसुप्रीम कोर्ट के फैसले के बाद चुनावी फंडिंग की पारदर्शिता में क्या बदलाव आया? हमारे वरिष्ठ विश्लेषक ने दस्तावेज़ों और आंकड़ों के आधार पर पूरी पड़ताल की।\n\n🔍 मुख्य बिंदु:\n• SBI का डेटा\n• EC की नई नीति\n• अगले चुनाव पर असर\n\n🔗 gyanvarta.in/politics/...",
  whatsapp_channel: "📌 *ज्ञानवार्ता — आज का विश्लेषण*\n\nचुनावी बॉन्ड पर SC फैसले के 6 महीने बाद — क्या बदला?\n\n👉 पूरा विश्लेषण: gyanvarta.in/politics/...",
  linkedin:         "चुनावी बॉन्ड और भारतीय लोकतंत्र: एक विश्लेषण\n\nफरवरी 2024 में भारत के सर्वोच्च न्यायालय ने चुनावी बॉन्ड योजना को असंवैधानिक घोषित किया। छह महीने बाद, हमने दस्तावेज़ों और विशेषज्ञ मतों के आधार पर पड़ताल की।\n\n3 मुख्य निष्कर्ष जो हर नागरिक को जानने चाहिए:\n\n1. पारदर्शिता में सुधार — लेकिन पूर्ण नहीं\n2. राजनीतिक फंडिंग पैटर्न में बदलाव\n3. भविष्य की चुनौतियाँ\n\n🔗 gyanvarta.in/politics/...\n\n#India #Democracy #Elections #Transparency",
  threads:          "चुनावी बॉन्ड — 6 महीने बाद सच क्या है?\n\nसुप्रीम कोर्ट के फैसले के बाद क्या बदला? दस्तावेज़ों पर आधारित पूरा विश्लेषण पढ़ें 👇\n\ngyanvarta.in/politics/...",
  youtube:          "🎥 नया वीडियो: चुनावी बॉन्ड — 6 महीने बाद\n\nसुप्रीम कोर्ट के ऐतिहासिक फैसले के बाद भारतीय चुनावी व्यवस्था में क्या बदला?\n\n📌 इस वीडियो में:\n• पूरा timeline\n• दस्तावेज़ विश्लेषण\n• विशेषज्ञ मत\n• आगे क्या?\n\n🔔 Channel subscribe करें और 🔔 bell दबाएं!",
};

function PostCard({
  platform,
  post,
  onUpdate,
  onApprove,
  onSchedule,
}: {
  platform: Platform;
  post: SocialPost;
  onUpdate: (content: string) => void;
  onApprove: () => void;
  onSchedule: (time: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(post.content);
  const [showSchedule, setShowSchedule] = useState(false);
  const [schedTime, setSchedTime] = useState("");

  const charLimit = platform.maxChars;
  const chars = draft.length;
  const overLimit = charLimit ? chars > charLimit : false;

  return (
    <div className={`border rounded-xl overflow-hidden bg-white ${
      post.status === "approved" ? "border-green-200" :
      post.status === "scheduled" ? "border-blue-200" :
      "border-slate-200"
    }`}>
      {/* Header */}
      <div className={`flex items-center justify-between px-4 py-3 border-b ${platform.bg}`}>
        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold ${platform.color} w-6 h-6 flex items-center justify-center`}>
            {platform.abbr}
          </span>
          <span className="text-sm font-semibold text-slate-700">{platform.name}</span>
          <span className="text-xs text-slate-400">{platform.note}</span>
        </div>
        <div className="flex items-center gap-2">
          {charLimit && (
            <span className={`text-xs font-mono ${overLimit ? "text-red-500 font-bold" : "text-slate-400"}`}>
              {chars}/{charLimit}
            </span>
          )}
          {post.status === "approved" && (
            <span className="text-xs font-semibold text-green-700 bg-green-100 px-2 py-0.5 rounded-full">✓ स्वीकृत</span>
          )}
          {post.status === "scheduled" && (
            <span className="text-xs font-semibold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-full">
              📅 {post.scheduledAt}
            </span>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {editing ? (
          <textarea
            value={draft}
            onChange={(e) => {
              setDraft(e.target.value);
              onUpdate(e.target.value);
            }}
            rows={6}
            className={`w-full text-sm text-slate-700 leading-relaxed border rounded-lg p-3 outline-none resize-y font-sans ${
              overLimit ? "border-red-300 focus:border-red-400" : "border-slate-200 focus:border-blue-400"
            }`}
          />
        ) : (
          <pre className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap font-sans">
            {post.content}
          </pre>
        )}
      </div>

      {/* Actions */}
      <div className="px-4 pb-4 flex flex-wrap gap-2">
        {editing ? (
          <>
            <button
              onClick={() => { setEditing(false); onUpdate(draft); }}
              className="text-xs px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >✓ Save</button>
            <button
              onClick={() => { setEditing(false); setDraft(post.content); }}
              className="text-xs px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-50"
            >Cancel</button>
          </>
        ) : (
          <>
            <button
              onClick={() => setEditing(true)}
              className="text-xs px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-50"
            >✏ Edit</button>
            {post.status !== "approved" && post.status !== "scheduled" && (
              <button
                onClick={onApprove}
                className="text-xs px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >✓ Approve</button>
            )}
            <button
              onClick={() => setShowSchedule(!showSchedule)}
              className="text-xs px-3 py-1.5 border border-blue-200 text-blue-600 rounded-lg hover:bg-blue-50"
            >📅 Schedule</button>
            <button
              onClick={() => navigator.clipboard.writeText(post.content)}
              className="text-xs px-3 py-1.5 border border-slate-200 text-slate-400 rounded-lg hover:bg-slate-50"
            >📋 Copy</button>
          </>
        )}

        {showSchedule && (
          <div className="w-full flex gap-2 mt-1">
            <input
              type="datetime-local"
              value={schedTime}
              onChange={(e) => setSchedTime(e.target.value)}
              className="flex-1 text-xs border border-slate-200 rounded-lg px-2 py-1.5 outline-none focus:border-blue-400"
            />
            <button
              onClick={() => { onSchedule(schedTime); setShowSchedule(false); }}
              className="text-xs px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >Set</button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function SocialMediaGenerator() {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    titleHi: "",
    summary: "",
    slug: "",
    category: "politics",
    keyPoints: ["", "", ""],
  });
  const [posts, setPosts] = useState<Record<string, SocialPost>>({});
  const [selectedPlatforms, setSelectedPlatforms] = useState<Set<string>>(
    new Set(PLATFORMS.map((p) => p.id))
  );

  const handleGenerate = async () => {
    if (!form.titleHi.trim()) return;
    setLoading(true);
    // Simulate API call (replace with: await api.ai.socialGenerate(form))
    await new Promise((r) => setTimeout(r, 2000));

    const generated: Record<string, SocialPost> = {};
    PLATFORMS.forEach((p) => {
      if (selectedPlatforms.has(p.id)) {
        generated[p.id] = {
          platform: p.id,
          content: SAMPLE_POSTS[p.id] || `${form.titleHi}\n\n${form.summary}\n\n🔗 gyanvarta.in/${form.category}/${form.slug}`,
          charCount: (SAMPLE_POSTS[p.id] || "").length,
          status: "pending",
        };
      }
    });
    setPosts(generated);
    setLoading(false);
    setStep(2);
  };

  const updatePost = (pid: string, content: string) => {
    setPosts((prev) => ({
      ...prev,
      [pid]: { ...prev[pid], content, charCount: content.length },
    }));
  };

  const approvePost = (pid: string) => {
    setPosts((prev) => ({ ...prev, [pid]: { ...prev[pid], status: "approved" } }));
  };

  const schedulePost = (pid: string, time: string) => {
    const formatted = new Date(time).toLocaleString("hi-IN", {
      month: "short", day: "numeric", hour: "2-digit", minute: "2-digit",
    });
    setPosts((prev) => ({
      ...prev,
      [pid]: { ...prev[pid], status: "scheduled", scheduledAt: formatted },
    }));
  };

  const approvedCount = Object.values(posts).filter(
    (p) => p.status === "approved" || p.status === "scheduled"
  ).length;

  return (
    <div className="max-w-5xl mx-auto">

      {/* Progress */}
      <div className="flex items-center gap-0 mb-8">
        {[
          { n: 1, label: "Article Info" },
          { n: 2, label: "Review Posts" },
          { n: 3, label: "Schedule & Publish" },
        ].map((s, i) => (
          <div key={s.n} className="flex items-center flex-1 last:flex-none">
            <div className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              step === s.n ? "bg-blue-600 text-white" :
              step > s.n ? "bg-green-100 text-green-700" :
              "bg-slate-100 text-slate-400"
            }`}>
              <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold border-2 border-current">
                {step > s.n ? "✓" : s.n}
              </span>
              {s.label}
            </div>
            {i < 2 && <div className="flex-1 h-px bg-slate-200 mx-2" />}
          </div>
        ))}
      </div>

      {/* ── Step 1: Article Info ──────────────────────── */}
      {step === 1 && (
        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-5">
            <div className="bg-white rounded-xl border border-slate-200 p-6">
              <h3 className="font-semibold text-slate-800 mb-5">Article Details</h3>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-2">
                    शीर्षक (Hindi) *
                  </label>
                  <input
                    value={form.titleHi}
                    onChange={(e) => setForm({ ...form, titleHi: e.target.value })}
                    placeholder="Article का हिंदी शीर्षक"
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm outline-none focus:border-blue-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-2">
                    सारांश
                  </label>
                  <textarea
                    value={form.summary}
                    onChange={(e) => setForm({ ...form, summary: e.target.value })}
                    rows={3}
                    placeholder="2-3 वाक्य में article का सारांश..."
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm outline-none focus:border-blue-400 resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-2">
                      URL Slug
                    </label>
                    <input
                      value={form.slug}
                      onChange={(e) => setForm({ ...form, slug: e.target.value })}
                      placeholder="article-slug"
                      className="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm outline-none focus:border-blue-400 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-2">
                      Category
                    </label>
                    <select
                      value={form.category}
                      onChange={(e) => setForm({ ...form, category: e.target.value })}
                      className="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm outline-none focus:border-blue-400 bg-white"
                    >
                      {["politics","economy","society","world","constitution","fact-check","opinion"].map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide block mb-2">
                    Key Points (3)
                  </label>
                  {form.keyPoints.map((kp, i) => (
                    <input
                      key={i}
                      value={kp}
                      onChange={(e) => {
                        const pts = [...form.keyPoints];
                        pts[i] = e.target.value;
                        setForm({ ...form, keyPoints: pts });
                      }}
                      placeholder={`मुख्य बिंदु ${i + 1}...`}
                      className="w-full px-4 py-2 border border-slate-200 rounded-lg text-sm outline-none focus:border-blue-400 mb-2"
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Platform selector */}
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h3 className="font-semibold text-slate-800 mb-4">Platforms</h3>
            <div className="space-y-2">
              {PLATFORMS.map((p) => (
                <label key={p.id} className="flex items-center gap-3 cursor-pointer group">
                  <input
                    type="checkbox"
                    checked={selectedPlatforms.has(p.id)}
                    onChange={(e) => {
                      const next = new Set(selectedPlatforms);
                      e.target.checked ? next.add(p.id) : next.delete(p.id);
                      setSelectedPlatforms(next);
                    }}
                    className="w-4 h-4 accent-blue-600"
                  />
                  <div className={`w-8 h-8 rounded-lg ${p.bg} flex items-center justify-center text-xs font-bold ${p.color} flex-shrink-0`}>
                    {p.abbr}
                  </div>
                  <div>
                    <p className="text-xs font-medium text-slate-700">{p.name}</p>
                    {p.maxChars && <p className="text-[10px] text-slate-400">max {p.maxChars} chars</p>}
                  </div>
                </label>
              ))}
            </div>
            <div className="mt-5 pt-4 border-t border-slate-100">
              <p className="text-xs text-slate-400 mb-3">{selectedPlatforms.size} platforms selected</p>
              <button
                onClick={handleGenerate}
                disabled={loading || !form.titleHi.trim()}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>✨ Generate Posts</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Step 2: Review posts ──────────────────────── */}
      {step === 2 && (
        <div>
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-semibold text-slate-800">Posts Review</h3>
              <p className="text-sm text-slate-500 mt-0.5">
                {approvedCount}/{Object.keys(posts).length} posts approved
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                className="px-4 py-2 border border-slate-200 text-sm text-slate-600 rounded-lg hover:bg-slate-50"
              >← वापस</button>
              <button
                onClick={() => {
                  Object.keys(posts).forEach((pid) => approvePost(pid));
                }}
                className="px-4 py-2 border border-green-200 text-sm text-green-700 rounded-lg hover:bg-green-50"
              >✓ सब Approve करें</button>
              <button
                onClick={() => setStep(3)}
                disabled={approvedCount === 0}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white text-sm font-semibold rounded-lg"
              >Schedule & Publish →</button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {PLATFORMS.filter((p) => selectedPlatforms.has(p.id) && posts[p.id]).map((p) => (
              <PostCard
                key={p.id}
                platform={p}
                post={posts[p.id]}
                onUpdate={(content) => updatePost(p.id, content)}
                onApprove={() => approvePost(p.id)}
                onSchedule={(time) => schedulePost(p.id, time)}
              />
            ))}
          </div>
        </div>
      )}

      {/* ── Step 3: Summary & Publish ────────────────── */}
      {step === 3 && (
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-xl border border-slate-200 p-6">
            <h3 className="font-semibold text-slate-800 mb-5">Publishing Summary</h3>

            {PLATFORMS.filter((p) => posts[p.id]).map((p) => (
              <div key={p.id} className="flex items-center gap-3 py-3 border-b border-slate-50 last:border-0">
                <div className={`w-8 h-8 rounded-lg ${p.bg} flex items-center justify-center text-xs font-bold ${p.color}`}>
                  {p.abbr}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-700">{p.name}</p>
                  <p className="text-xs text-slate-400">{posts[p.id]?.charCount} chars</p>
                </div>
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                  posts[p.id]?.status === "approved"  ? "bg-green-100 text-green-700" :
                  posts[p.id]?.status === "scheduled" ? "bg-blue-100 text-blue-700" :
                  "bg-slate-100 text-slate-500"
                }`}>
                  {posts[p.id]?.status === "approved"  ? "✓ Approved" :
                   posts[p.id]?.status === "scheduled" ? `📅 ${posts[p.id]?.scheduledAt}` :
                   "Pending"}
                </span>
              </div>
            ))}

            <div className="mt-6 pt-5 border-t border-slate-100 space-y-3">
              <button className="w-full py-3 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl text-sm transition-colors">
                🚀 Publish All Approved ({Object.values(posts).filter((p) => p.status === "approved").length} posts)
              </button>
              <button className="w-full py-3 border border-slate-200 text-slate-600 hover:bg-slate-50 rounded-xl text-sm">
                📅 Add to Queue (Scheduled)
              </button>
              <button
                onClick={() => setStep(2)}
                className="w-full py-2.5 text-slate-400 hover:text-slate-600 text-sm"
              >← Review में वापस जाएं</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
