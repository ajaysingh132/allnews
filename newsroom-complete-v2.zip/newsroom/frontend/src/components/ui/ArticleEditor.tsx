"use client";
import { useEditor, EditorContent, BubbleMenu } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Image from "@tiptap/extension-image";
import Link from "@tiptap/extension-link";
import { useState, useCallback } from "react";

type ToolbarBtnProps = {
  onClick: () => void;
  active?: boolean;
  title: string;
  children: React.ReactNode;
};

function ToolbarBtn({ onClick, active, title, children }: ToolbarBtnProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className={`px-2.5 py-1.5 rounded text-sm transition-colors ${
        active
          ? "bg-blue-100 text-blue-700 font-semibold"
          : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
      }`}
    >
      {children}
    </button>
  );
}

function ToolbarSep() {
  return <div className="w-px h-5 bg-slate-200 mx-1" />;
}

type ArticleEditorProps = {
  initialContent?: string;
  onChange?: (html: string, text: string) => void;
  placeholder?: string;
};

export default function ArticleEditor({
  initialContent = "",
  onChange,
  placeholder = "यहाँ लेख लिखें...",
}: ArticleEditorProps) {
  const [wordCount, setWordCount] = useState(0);
  const [linkUrl, setLinkUrl] = useState("");
  const [showLinkInput, setShowLinkInput] = useState(false);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [2, 3, 4] },
        bulletList: { keepMarks: true },
        orderedList: { keepMarks: true },
      }),
      Image.configure({ allowBase64: true, inline: false }),
      Link.configure({
        openOnClick: false,
        HTMLAttributes: { class: "text-blue-600 underline" },
      }),
    ],
    content: initialContent,
    editorProps: {
      attributes: {
        class:
          "prose-hindi min-h-[400px] px-6 py-5 outline-none focus:outline-none",
        "data-placeholder": placeholder,
      },
    },
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      const text = editor.getText();
      const words = text.trim().split(/\s+/).filter(Boolean).length;
      setWordCount(words);
      onChange?.(html, text);
    },
  });

  const addLink = useCallback(() => {
    if (!linkUrl || !editor) return;
    editor
      .chain()
      .focus()
      .extendMarkRange("link")
      .setLink({ href: linkUrl })
      .run();
    setLinkUrl("");
    setShowLinkInput(false);
  }, [editor, linkUrl]);

  const addImage = useCallback(() => {
    const url = prompt("Image URL:");
    if (url && editor) {
      editor.chain().focus().setImage({ src: url }).run();
    }
  }, [editor]);

  if (!editor) return null;

  const readingTime = Math.max(1, Math.ceil(wordCount / 150));

  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">

      {/* ── Toolbar ──────────────────────────────────── */}
      <div className="flex flex-wrap items-center gap-0.5 px-3 py-2 border-b border-slate-200 bg-slate-50">

        {/* History */}
        <ToolbarBtn title="Undo" onClick={() => editor.chain().focus().undo().run()}>↩</ToolbarBtn>
        <ToolbarBtn title="Redo" onClick={() => editor.chain().focus().redo().run()}>↪</ToolbarBtn>
        <ToolbarSep />

        {/* Headings */}
        <ToolbarBtn
          title="Heading 2"
          active={editor.isActive("heading", { level: 2 })}
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
        >H2</ToolbarBtn>
        <ToolbarBtn
          title="Heading 3"
          active={editor.isActive("heading", { level: 3 })}
          onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
        >H3</ToolbarBtn>
        <ToolbarSep />

        {/* Marks */}
        <ToolbarBtn
          title="Bold"
          active={editor.isActive("bold")}
          onClick={() => editor.chain().focus().toggleBold().run()}
        ><strong>B</strong></ToolbarBtn>
        <ToolbarBtn
          title="Italic"
          active={editor.isActive("italic")}
          onClick={() => editor.chain().focus().toggleItalic().run()}
        ><em>I</em></ToolbarBtn>
        <ToolbarBtn
          title="Strikethrough"
          active={editor.isActive("strike")}
          onClick={() => editor.chain().focus().toggleStrike().run()}
        ><s>S</s></ToolbarBtn>
        <ToolbarBtn
          title="Code"
          active={editor.isActive("code")}
          onClick={() => editor.chain().focus().toggleCode().run()}
        >`c`</ToolbarBtn>
        <ToolbarSep />

        {/* Lists */}
        <ToolbarBtn
          title="Bullet List"
          active={editor.isActive("bulletList")}
          onClick={() => editor.chain().focus().toggleBulletList().run()}
        >• सूची</ToolbarBtn>
        <ToolbarBtn
          title="Numbered List"
          active={editor.isActive("orderedList")}
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
        >1. सूची</ToolbarBtn>
        <ToolbarSep />

        {/* Blocks */}
        <ToolbarBtn
          title="Blockquote"
          active={editor.isActive("blockquote")}
          onClick={() => editor.chain().focus().toggleBlockquote().run()}
        >" उद्धरण</ToolbarBtn>
        <ToolbarBtn
          title="Horizontal Rule"
          onClick={() => editor.chain().focus().setHorizontalRule().run()}
        >── विभाजक</ToolbarBtn>
        <ToolbarSep />

        {/* Link */}
        <div className="relative">
          <ToolbarBtn
            title="Link"
            active={editor.isActive("link") || showLinkInput}
            onClick={() => setShowLinkInput(!showLinkInput)}
          >🔗 Link</ToolbarBtn>
          {showLinkInput && (
            <div className="absolute top-full left-0 mt-1 z-10 bg-white border border-slate-200 rounded-lg shadow-lg p-2 flex gap-2 min-w-64">
              <input
                autoFocus
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") addLink(); if (e.key === "Escape") setShowLinkInput(false); }}
                placeholder="https://..."
                className="flex-1 px-2 py-1 text-sm border border-slate-200 rounded outline-none focus:border-blue-400"
              />
              <button
                type="button"
                onClick={addLink}
                className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
              >Add</button>
              <button
                type="button"
                onClick={() => editor.chain().focus().unsetLink().run()}
                className="px-2 py-1 text-red-600 text-sm rounded hover:bg-red-50"
                title="Remove link"
              >✕</button>
            </div>
          )}
        </div>

        {/* Image */}
        <ToolbarBtn title="Image" onClick={addImage}>🖼 Image</ToolbarBtn>
        <ToolbarSep />

        {/* Clear */}
        <ToolbarBtn
          title="Clear formatting"
          onClick={() => editor.chain().focus().clearNodes().unsetAllMarks().run()}
        >✕ Format</ToolbarBtn>
      </div>

      {/* ── Bubble Menu (selection) ───────────────────── */}
      {editor && (
        <BubbleMenu
          editor={editor}
          tippyOptions={{ duration: 100 }}
          className="flex items-center gap-1 bg-[#1a2744] rounded-lg px-2 py-1.5 shadow-xl"
        >
          {[
            { cmd: () => editor.chain().focus().toggleBold().run(), active: editor.isActive("bold"), label: "B", cls: "font-bold" },
            { cmd: () => editor.chain().focus().toggleItalic().run(), active: editor.isActive("italic"), label: "I", cls: "italic" },
            { cmd: () => editor.chain().focus().toggleStrike().run(), active: editor.isActive("strike"), label: "S", cls: "line-through" },
          ].map((b) => (
            <button
              key={b.label}
              type="button"
              onClick={b.cmd}
              className={`px-2 py-0.5 rounded text-sm ${b.cls} ${b.active ? "bg-white text-[#1a2744]" : "text-white hover:bg-white/20"}`}
            >{b.label}</button>
          ))}
          <div className="w-px h-4 bg-white/20 mx-1" />
          <button
            type="button"
            onClick={() => {
              setLinkUrl("");
              setShowLinkInput(true);
            }}
            className="px-2 py-0.5 rounded text-xs text-white hover:bg-white/20"
          >🔗</button>
        </BubbleMenu>
      )}

      {/* ── Editor area ──────────────────────────────── */}
      <EditorContent editor={editor} />

      {/* ── Status bar ───────────────────────────────── */}
      <div className="flex items-center justify-between px-4 py-2 border-t border-slate-100 bg-slate-50 text-xs text-slate-400">
        <div className="flex items-center gap-4">
          <span>{wordCount} शब्द</span>
          <span>~{readingTime} मिनट पठन</span>
        </div>
        <div className="flex items-center gap-3">
          {editor.isActive("bold") && <span className="text-blue-500">Bold</span>}
          {editor.isActive("link") && (
            <button
              type="button"
              onClick={() => editor.chain().focus().unsetLink().run()}
              className="text-red-400 hover:text-red-600"
            >Link हटाएं</button>
          )}
          <span className="text-slate-300">Ctrl+Z = Undo</span>
        </div>
      </div>
    </div>
  );
}
