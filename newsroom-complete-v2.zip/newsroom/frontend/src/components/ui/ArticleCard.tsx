import Link from "next/link";
import type { Article } from "@/lib/api";

type Size = "large" | "medium" | "small" | "mini";

function ContentTypeBadge({ type }: { type: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    article:       { label: "समाचार",      cls: "bg-slate-100 text-slate-600" },
    analysis:      { label: "विश्लेषण",    cls: "bg-blue-50 text-blue-700" },
    interview:     { label: "संवाद",       cls: "bg-purple-50 text-purple-700" },
    fact_check:    { label: "तथ्य-जाँच",   cls: "bg-green-50 text-green-700" },
    ground_report: { label: "ग्राउंड रिपोर्ट", cls: "bg-amber-50 text-amber-700" },
    explainer:     { label: "व्याख्याता",  cls: "bg-teal-50 text-teal-700" },
    opinion:       { label: "विचार",       cls: "bg-rose-50 text-rose-700" },
    special_report:{ label: "विशेष रिपोर्ट", cls: "bg-indigo-50 text-indigo-700" },
    research:      { label: "शोध",         cls: "bg-orange-50 text-orange-700" },
  };
  const cfg = map[type] || map.article;
  return (
    <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded ${cfg.cls}`}>
      {cfg.label}
    </span>
  );
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins} मिनट पहले`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} घंटे पहले`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days} दिन पहले`;
  return new Date(iso).toLocaleDateString("hi-IN", { year: "numeric", month: "short", day: "numeric" });
}

function articleHref(a: Article) {
  return `/${a.category?.slug || "uncategorized"}/${a.slug}`;
}

// ── Large (Hero) card ─────────────────────────────────────
export function ArticleCardLarge({ article: a }: { article: Article }) {
  return (
    <Link href={articleHref(a)} className="group block">
      <div className="relative overflow-hidden rounded-xl bg-slate-100 mb-4" style={{ aspectRatio: "16/9" }}>
        {a.heroImageUrl ? (
          <img
            src={a.heroImageUrl}
            alt={a.titleHi}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-[#1a2744] to-[#2563eb] flex items-center justify-center">
            <span className="text-white/30 text-4xl font-bold">ज्ञ</span>
          </div>
        )}
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        <div className="absolute bottom-3 left-3">
          <ContentTypeBadge type={a.contentType} />
        </div>
      </div>

      <div className="flex items-center gap-2 mb-2 text-xs text-slate-500">
        <span className="font-medium text-blue-700">{a.category?.nameHi}</span>
        <span>·</span>
        <span>{timeAgo(a.publishedAt)}</span>
        {a.readingTimeMins && <><span>·</span><span>{a.readingTimeMins} मिनट</span></>}
      </div>

      <h2 className="text-xl font-semibold text-slate-900 leading-snug mb-2 group-hover:text-blue-700 transition-colors">
        {a.titleHi}
      </h2>

      {a.summary && (
        <p className="text-sm text-slate-600 leading-relaxed line-clamp-2">{a.summary}</p>
      )}

      {a.authors?.[0] && (
        <div className="flex items-center gap-2 mt-3">
          <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 text-[10px] font-bold">
            {a.authors[0].user.name[0]}
          </div>
          <span className="text-xs text-slate-500">{a.authors[0].user.name}</span>
          {a.isAiAssisted && (
            <span className="text-[10px] text-purple-600 border border-purple-200 rounded px-1.5 py-0.5">AI-सहायता</span>
          )}
        </div>
      )}
    </Link>
  );
}

// ── Medium card ───────────────────────────────────────────
export function ArticleCardMedium({ article: a }: { article: Article }) {
  return (
    <Link href={articleHref(a)} className="group flex gap-3 card-lift">
      <div className="relative rounded-lg overflow-hidden flex-shrink-0 w-24 h-24 bg-slate-100">
        {a.heroImageUrl ? (
          <img src={a.heroImageUrl} alt={a.titleHi} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center">
            <span className="text-slate-400 text-lg font-bold">ज्ञ</span>
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 mb-1">
          <span className="text-[10px] font-semibold text-blue-600">{a.category?.nameHi}</span>
          <span className="text-slate-300">·</span>
          <ContentTypeBadge type={a.contentType} />
        </div>
        <h3 className="text-sm font-semibold text-slate-800 leading-snug line-clamp-2 group-hover:text-blue-700 transition-colors mb-1">
          {a.titleHi}
        </h3>
        <p className="text-xs text-slate-400">
          {timeAgo(a.publishedAt)}
          {a.readingTimeMins && ` · ${a.readingTimeMins} मिनट`}
        </p>
      </div>
    </Link>
  );
}

// ── Small / list card ─────────────────────────────────────
export function ArticleCardSmall({ article: a }: { article: Article }) {
  return (
    <Link href={articleHref(a)} className="group block py-3 border-b border-slate-100 last:border-0">
      <div className="flex items-center gap-2 mb-1">
        <ContentTypeBadge type={a.contentType} />
        <span className="text-[10px] text-slate-400">{timeAgo(a.publishedAt)}</span>
      </div>
      <h3 className="text-sm font-medium text-slate-800 leading-snug line-clamp-2 group-hover:text-blue-700 transition-colors">
        {a.titleHi}
      </h3>
    </Link>
  );
}

// ── Fact Check card ───────────────────────────────────────
export function FactCheckCard({ article: a, verdict }: { article: Article; verdict?: "fact" | "claim" | "false" | "misleading" }) {
  const verdictMap = {
    fact:      { label: "तथ्य", cls: "bg-green-50 border-green-300 text-green-700" },
    claim:     { label: "दावा", cls: "bg-amber-50 border-amber-300 text-amber-700" },
    false:     { label: "असत्य", cls: "bg-red-50 border-red-300 text-red-700" },
    misleading:{ label: "भ्रामक", cls: "bg-orange-50 border-orange-300 text-orange-700" },
  };
  const v = verdict ? verdictMap[verdict] : verdictMap.claim;

  return (
    <Link href={articleHref(a)} className="group block p-4 rounded-xl border border-slate-200 hover:border-blue-200 bg-white transition-colors card-lift">
      <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-semibold mb-3 ${v.cls}`}>
        {verdict === "fact" ? "✓" : verdict === "false" ? "✗" : "!"} {v.label}
      </div>
      <p className="text-sm font-medium text-slate-800 leading-snug line-clamp-2 group-hover:text-blue-700 transition-colors">
        {a.titleHi}
      </p>
      <p className="text-xs text-slate-400 mt-2">{timeAgo(a.publishedAt)}</p>
    </Link>
  );
}
