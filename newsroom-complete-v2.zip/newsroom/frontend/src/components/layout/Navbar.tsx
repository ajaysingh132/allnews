"use client";
import { useState, useEffect } from "react";
import Link from "next/link";

const NAV_LINKS = [
  { label: "समाचार", href: "/category/samachar" },
  { label: "विश्लेषण", href: "/category/vishleshan" },
  { label: "संवाद", href: "/category/samvad" },
  { label: "तथ्य-जाँच", href: "/fact-check" },
  { label: "दस्तावेज़", href: "/documents" },
  { label: "शोध", href: "/research" },
  { label: "वीडियो", href: "/video" },
  { label: "पॉडकास्ट", href: "/podcasts" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQ, setSearchQ] = useState("");

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <>
      {/* Breaking ticker */}
      <div className="bg-[#1a2744] text-white py-1.5 px-4 overflow-hidden">
        <div className="flex items-center gap-3 max-w-7xl mx-auto">
          <span className="text-orange-400 font-semibold text-xs whitespace-nowrap shrink-0 flex items-center gap-1">
            <span className="inline-block w-1.5 h-1.5 bg-orange-400 rounded-full animate-pulse" />
            ताज़ा
          </span>
          <div className="overflow-hidden flex-1">
            <div className="ticker-inner text-xs text-slate-300">
              <span>सर्वोच्च न्यायालय का ऐतिहासिक फैसला आज</span>
              <span className="mx-6 text-slate-600">·</span>
              <span>संसद में बजट पर बहस जारी</span>
              <span className="mx-6 text-slate-600">·</span>
              <span>तीन राज्यों में चुनाव की तारीखें घोषित</span>
              <span className="mx-6 text-slate-600">·</span>
              <span>रूस-यूक्रेन वार्ता का नया दौर शुरू</span>
              <span className="mx-6 text-slate-600">·</span>
              {/* duplicate for seamless loop */}
              <span>सर्वोच्च न्यायालय का ऐतिहासिक फैसला आज</span>
              <span className="mx-6 text-slate-600">·</span>
              <span>संसद में बजट पर बहस जारी</span>
              <span className="mx-6 text-slate-600">·</span>
              <span>तीन राज्यों में चुनाव की तारीखें घोषित</span>
              <span className="mx-6 text-slate-600">·</span>
              <span>रूस-यूक्रेन वार्ता का नया दौर शुरू</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main navbar */}
      <header
        className={`sticky top-0 z-50 bg-white transition-shadow duration-200 ${
          scrolled ? "shadow-md" : "border-b border-slate-200"
        }`}
      >
        <nav className="max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-4 h-14">

            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 shrink-0 mr-2">
              <div className="w-8 h-8 bg-[#1a2744] rounded-lg flex items-center justify-center">
                <span className="text-orange-400 font-bold text-sm">ज्ञ</span>
              </div>
              <span className="font-bold text-[#1a2744] text-lg tracking-tight leading-none">
                ज्ञान<span className="text-orange-500">वार्ता</span>
              </span>
            </Link>

            {/* Desktop nav */}
            <div className="hidden lg:flex items-center gap-0.5 flex-1 overflow-hidden">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="px-3 py-1.5 text-sm text-slate-600 hover:text-[#1a2744] hover:bg-slate-50 rounded-md whitespace-nowrap transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Right actions */}
            <div className="ml-auto flex items-center gap-2">

              {/* Search */}
              {searchOpen ? (
                <div className="flex items-center gap-2">
                  <input
                    autoFocus
                    value={searchQ}
                    onChange={(e) => setSearchQ(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && searchQ.trim())
                        window.location.href = `/search?q=${encodeURIComponent(searchQ)}`;
                      if (e.key === "Escape") setSearchOpen(false);
                    }}
                    placeholder="खोजें..."
                    className="w-48 text-sm border border-slate-300 rounded-lg px-3 py-1.5 outline-none focus:border-blue-500"
                  />
                  <button
                    onClick={() => setSearchOpen(false)}
                    className="text-slate-400 hover:text-slate-600"
                    aria-label="बंद करें"
                  >✕</button>
                </div>
              ) : (
                <button
                  onClick={() => setSearchOpen(true)}
                  aria-label="खोजें"
                  className="p-2 text-slate-500 hover:text-[#1a2744] hover:bg-slate-100 rounded-lg"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <circle cx="11" cy="11" r="8" strokeWidth="2"/>
                    <path d="m21 21-4.35-4.35" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </button>
              )}

              {/* LIVE */}
              <Link
                href="/live"
                className="hidden sm:flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 transition-colors"
              >
                <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                LIVE
              </Link>

              {/* Social icons */}
              <div className="hidden md:flex items-center gap-1">
                {[
                  { icon: "YT", href: "https://youtube.com/@gyanvarta", label: "YouTube", color: "text-red-600" },
                  { icon: "X", href: "https://x.com/gyanvarta", label: "X", color: "text-slate-800" },
                  { icon: "TG", href: "https://t.me/gyanvarta", label: "Telegram", color: "text-sky-500" },
                ].map((s) => (
                  <a
                    key={s.href}
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={s.label}
                    className={`p-1.5 rounded-md hover:bg-slate-100 text-xs font-bold ${s.color}`}
                  >
                    {s.icon}
                  </a>
                ))}
              </div>

              {/* Hamburger */}
              <button
                className="lg:hidden p-2 text-slate-500 hover:text-[#1a2744] hover:bg-slate-100 rounded-lg"
                onClick={() => setMenuOpen(!menuOpen)}
                aria-label="मेनू"
              >
                {menuOpen ? (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
                  </svg>
                ) : (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"/>
                  </svg>
                )}
              </button>
            </div>
          </div>

          {/* Mobile menu */}
          {menuOpen && (
            <div className="lg:hidden border-t border-slate-100 py-3 grid grid-cols-2 gap-1">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMenuOpen(false)}
                  className="px-3 py-2.5 text-sm text-slate-700 hover:bg-slate-50 rounded-lg"
                >
                  {link.label}
                </Link>
              ))}
              <Link
                href="/live"
                className="col-span-2 flex items-center justify-center gap-2 mt-2 py-2.5 bg-red-50 text-red-600 rounded-lg text-sm font-medium border border-red-200"
              >
                <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                LIVE देखें
              </Link>
            </div>
          )}
        </nav>
      </header>
    </>
  );
}
