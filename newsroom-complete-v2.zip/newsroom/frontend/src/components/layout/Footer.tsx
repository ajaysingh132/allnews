import Link from "next/link";

const FOOTER_COLS = [
  {
    title: "ज्ञानवार्ता",
    links: [
      { label: "हमारे बारे में", href: "/about" },
      { label: "संपादकीय नीति", href: "/editorial-policy" },
      { label: "तथ्य-जाँच नीति", href: "/fact-check-policy" },
      { label: "AI उपयोग नीति", href: "/ai-policy" },
      { label: "सुधार नीति", href: "/corrections" },
      { label: "संपर्क करें", href: "/contact" },
    ],
  },
  {
    title: "अनुभाग",
    links: [
      { label: "राजनीति", href: "/category/politics" },
      { label: "अर्थव्यवस्था", href: "/category/economy" },
      { label: "समाज", href: "/category/society" },
      { label: "संस्कृति", href: "/category/culture" },
      { label: "विश्व", href: "/category/world" },
      { label: "संविधान और कानून", href: "/category/constitution-law" },
    ],
  },
  {
    title: "प्रारूप",
    links: [
      { label: "वीडियो", href: "/video" },
      { label: "पॉडकास्ट", href: "/podcasts" },
      { label: "शोध रिपोर्ट", href: "/research" },
      { label: "पुस्तकें", href: "/books" },
      { label: "संग्रह", href: "/archive" },
      { label: "RSS Feed", href: "/feed.xml" },
    ],
  },
  {
    title: "सहयोग",
    links: [
      { label: "विज्ञापन", href: "/advertise" },
      { label: "प्रायोजन", href: "/sponsor" },
      { label: "Newsletter", href: "/newsletter" },
      { label: "गोपनीयता नीति", href: "/privacy" },
      { label: "नियम व शर्तें", href: "/terms" },
      { label: "विज्ञापन नीति", href: "/advertising-policy" },
    ],
  },
];

const SOCIAL = [
  { label: "YouTube", href: "https://youtube.com/@gyanvarta", abbr: "YT" },
  { label: "Facebook", href: "https://facebook.com/gyanvarta", abbr: "FB" },
  { label: "Instagram", href: "https://instagram.com/gyanvarta", abbr: "IG" },
  { label: "X", href: "https://x.com/gyanvarta", abbr: "X" },
  { label: "Telegram", href: "https://t.me/gyanvarta", abbr: "TG" },
  { label: "WhatsApp", href: "https://whatsapp.com/channel/gyanvarta", abbr: "WA" },
];

export default function Footer() {
  return (
    <footer className="bg-[#0f1a33] text-slate-300 mt-16">
      {/* Newsletter band */}
      <div className="bg-[#1a2744] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <p className="font-semibold text-white text-lg">दैनिक विश्लेषण Newsletter</p>
            <p className="text-sm text-slate-400 mt-1">हर सुबह — ताज़ा विश्लेषण, तथ्य और संदर्भ आपके inbox में</p>
          </div>
          <form
            onSubmit={(e) => e.preventDefault()}
            className="flex gap-3 w-full md:w-auto"
          >
            <input
              type="email"
              placeholder="आपका ईमेल पता"
              className="flex-1 md:w-72 px-4 py-2.5 rounded-lg bg-white/10 border border-white/20 text-white placeholder-slate-400 text-sm outline-none focus:border-blue-400"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-sm font-medium transition-colors whitespace-nowrap"
            >
              सदस्य बनें
            </button>
          </form>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Logo & tagline */}
        <div className="mb-10">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center">
              <span className="text-orange-400 font-bold">ज्ञ</span>
            </div>
            <span className="text-xl font-bold text-white">
              ज्ञान<span className="text-orange-400">वार्ता</span>
            </span>
          </div>
          <p className="text-slate-400 text-sm max-w-sm leading-relaxed">
            "आज की खबर को कल के ज्ञान में बदलना।" — समाचार से विश्लेषण, विश्लेषण से शोध, शोध से ज्ञान।
          </p>
          <p className="text-slate-500 text-xs mt-3">
            GBSBFORYOU Publications · Bhopal, Madhya Pradesh, India
          </p>
        </div>

        {/* Links grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
          {FOOTER_COLS.map((col) => (
            <div key={col.title}>
              <p className="text-white font-semibold text-sm mb-4">{col.title}</p>
              <ul className="space-y-2.5">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-slate-400 hover:text-white text-sm transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-slate-500 text-xs">
            © {new Date().getFullYear()} ज्ञानवार्ता · GBSBFORYOU Publications · सर्वाधिकार सुरक्षित
          </p>
          <div className="flex items-center gap-1.5">
            {SOCIAL.map((s) => (
              <a
                key={s.href}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={s.label}
                className="w-8 h-8 rounded-lg bg-white/8 hover:bg-white/15 flex items-center justify-center text-slate-400 hover:text-white text-xs font-bold transition-colors"
              >
                {s.abbr}
              </a>
            ))}
          </div>
        </div>

        {/* Editorial transparency note */}
        <div className="mt-6 pt-6 border-t border-white/5">
          <p className="text-slate-600 text-xs leading-relaxed max-w-3xl">
            ज्ञानवार्ता एक स्वतंत्र हिंदी समाचार विश्लेषण मंच है। हम किसी भी राजनीतिक दल, सरकार या कॉर्पोरेट संस्था से संबद्ध नहीं हैं। AI-सहायित सामग्री पर स्पष्ट प्रकटीकरण किया जाता है। प्रायोजित सामग्री को स्पष्ट रूप से चिह्नित किया जाता है। संपादकीय निर्णय पूर्णतः स्वतंत्र हैं।
          </p>
        </div>
      </div>
    </footer>
  );
}
