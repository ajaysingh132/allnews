"use client";

type Claim = {
  id: string;
  claimText: string;
  classification: string;
  madeBy?: string;
  isVerified: boolean;
};

const classificationConfig: Record<
  string,
  { label: string; bg: string; text: string; border: string; icon: string }
> = {
  fact: {
    label: "तथ्य", bg: "bg-green-50", text: "text-green-800",
    border: "border-green-300", icon: "✓",
  },
  claim: {
    label: "दावा", bg: "bg-amber-50", text: "text-amber-800",
    border: "border-amber-300", icon: "!",
  },
  official_statement: {
    label: "आधिकारिक बयान", bg: "bg-blue-50", text: "text-blue-800",
    border: "border-blue-300", icon: "🏛",
  },
  documented_evidence: {
    label: "प्रमाणित साक्ष्य", bg: "bg-teal-50", text: "text-teal-800",
    border: "border-teal-300", icon: "📄",
  },
  unverified: {
    label: "अपुष्ट", bg: "bg-red-50", text: "text-red-800",
    border: "border-red-300", icon: "?",
  },
  analysis: {
    label: "विश्लेषण", bg: "bg-purple-50", text: "text-purple-800",
    border: "border-purple-300", icon: "◈",
  },
  opinion: {
    label: "मत", bg: "bg-gray-50", text: "text-gray-700",
    border: "border-gray-300", icon: "💭",
  },
};

export function FactClaimBadge({ claim }: { claim: Claim }) {
  const config = classificationConfig[claim.classification] || classificationConfig.unverified;

  return (
    <div className={`flex gap-3 p-3 rounded-lg border ${config.bg} ${config.border}`}>
      <span className={`text-sm font-bold mt-0.5 ${config.text}`}>
        {config.icon}
      </span>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <span className={`text-xs font-semibold px-2 py-0.5 rounded ${config.bg} ${config.text} border ${config.border}`}>
            {config.label}
          </span>
          {claim.madeBy && (
            <span className="text-xs text-gray-500">— {claim.madeBy}</span>
          )}
          {claim.isVerified && (
            <span className="text-xs text-green-600 font-medium">✓ सत्यापित</span>
          )}
        </div>
        <p className={`text-sm leading-relaxed ${config.text}`}>{claim.claimText}</p>
      </div>
    </div>
  );
}

export function ShareButtons({ url, title }: { url: string; title: string }) {
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);

  const shareLinks = [
    {
      name: "X",
      href: `https://x.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`,
      bg: "bg-black text-white",
    },
    {
      name: "WhatsApp",
      href: `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`,
      bg: "bg-green-500 text-white",
    },
    {
      name: "Facebook",
      href: `https://facebook.com/sharer/sharer.php?u=${encodedUrl}`,
      bg: "bg-blue-600 text-white",
    },
    {
      name: "Telegram",
      href: `https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}`,
      bg: "bg-sky-500 text-white",
    },
    {
      name: "Copy",
      href: "#",
      bg: "bg-gray-100 text-gray-700",
      onClick: async (e: React.MouseEvent) => {
        e.preventDefault();
        await navigator.clipboard.writeText(url);
        alert("लिंक copy हो गया!");
      },
    },
  ];

  return (
    <div className="mt-10 pt-8 border-t">
      <p className="text-sm text-gray-500 mb-3">इस लेख को share करें:</p>
      <div className="flex flex-wrap gap-2">
        {shareLinks.map((link) => (
          <a
            key={link.name}
            href={link.href}
            target={link.href !== "#" ? "_blank" : undefined}
            rel="noopener noreferrer"
            onClick={link.onClick}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-opacity hover:opacity-80 ${link.bg}`}
          >
            {link.name}
          </a>
        ))}
      </div>
    </div>
  );
}

export function AuthorCard({
  author,
}: {
  author: { id: string; name: string; bio?: string; avatarUrl?: string };
}) {
  const initials = author.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl border border-gray-200">
      {author.avatarUrl ? (
        <img
          src={author.avatarUrl}
          alt={author.name}
          className="w-12 h-12 rounded-full object-cover flex-shrink-0"
        />
      ) : (
        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
          <span className="text-blue-700 font-semibold text-sm">{initials}</span>
        </div>
      )}
      <div>
        <p className="font-semibold text-gray-900">{author.name}</p>
        {author.bio && (
          <p className="text-sm text-gray-600 mt-1 leading-relaxed">{author.bio}</p>
        )}
      </div>
    </div>
  );
}

export function ArticleBody({ content }: { content: string }) {
  return (
    <div
      className="prose prose-hindi max-w-none prose-headings:font-semibold prose-p:leading-relaxed prose-p:text-gray-800"
      dangerouslySetInnerHTML={{ __html: content }}
    />
  );
}

export function SourcesList({
  sources,
}: {
  sources: Array<{ id: string; name: string; url?: string; sourceType: string; reliabilityStatus: string }>;
}) {
  return (
    <div className="mt-10 pt-8 border-t">
      <h3 className="font-semibold text-gray-800 mb-4">स्रोत और संदर्भ</h3>
      <div className="space-y-2">
        {sources.map((source) => (
          <div key={source.id} className="flex items-center gap-3 text-sm">
            <span className="px-2 py-0.5 rounded bg-gray-100 text-gray-600 text-xs">
              {source.sourceType}
            </span>
            {source.url ? (
              <a
                href={source.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                {source.name}
              </a>
            ) : (
              <span className="text-gray-700">{source.name}</span>
            )}
            <span
              className={`ml-auto text-xs ${
                source.reliabilityStatus === "high" ? "text-green-600" :
                source.reliabilityStatus === "medium" ? "text-amber-600" :
                "text-gray-400"
              }`}
            >
              {source.reliabilityStatus === "high" ? "✓ उच्च विश्वसनीयता" :
               source.reliabilityStatus === "medium" ? "मध्यम विश्वसनीयता" : ""}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function RelatedArticles({
  categoryId,
  currentArticleId,
}: {
  categoryId: string;
  currentArticleId: string;
}) {
  return (
    <div className="mt-12">
      <h3 className="text-xl font-semibold text-gray-800 mb-6">संबंधित लेख</h3>
      <p className="text-sm text-gray-500">
        इस श्रेणी के अन्य लेख यहाँ दिखाए जाएंगे।
      </p>
    </div>
  );
}
