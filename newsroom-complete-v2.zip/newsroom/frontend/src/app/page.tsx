import { Metadata } from "next";
import Link from "next/link";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import {
  ArticleCardLarge,
  ArticleCardMedium,
  ArticleCardSmall,
  FactCheckCard,
} from "@/components/ui/ArticleCard";
import { api, Article } from "@/lib/api";

export const metadata: Metadata = {
  title: "ज्ञानवार्ता — हिंदी समाचार विश्लेषण | आज की खबर, कल का ज्ञान",
  description: "गहन विश्लेषण, तथ्य-जाँच और शोध। राजनीति, अर्थव्यवस्था, समाज और संस्कृति पर Hindi में विश्वसनीय पत्रकारिता।",
};

// ── Section heading ───────────────────────────────────────
function SectionHead({
  title,
  href,
  icon,
}: {
  title: string;
  href?: string;
  icon?: string;
}) {
  return (
    <div className="flex items-center justify-between mb-5">
      <div className="flex items-center gap-2">
        {icon && <span className="text-lg">{icon}</span>}
        <h2 className="text-lg font-bold text-[#1a2744] tracking-tight">{title}</h2>
        <div className="h-px flex-1 bg-gradient-to-r from-blue-200 to-transparent w-16 ml-2" />
      </div>
      {href && (
        <Link
          href={href}
          className="text-xs font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1"
        >
          सभी देखें →
        </Link>
      )}
    </div>
  );
}

// ── Newsletter box ────────────────────────────────────────
function NewsletterBox() {
  return (
    <div className="bg-gradient-to-br from-[#1a2744] to-[#1e3a8a] rounded-2xl p-6 text-white">
      <p className="text-xs font-semibold text-blue-300 uppercase tracking-widest mb-2">
        Newsletter
      </p>
      <h3 className="text-lg font-bold mb-1">दैनिक विश्लेषण</h3>
      <p className="text-blue-200 text-sm mb-5 leading-relaxed">
        हर सुबह — ताज़ा विश्लेषण, तथ्य और संदर्भ सीधे inbox में
      </p>
      <form onSubmit={(e) => e.preventDefault()} className="space-y-2.5">
        <input
          type="email"
          placeholder="आपका ईमेल पता"
          className="w-full px-4 py-2.5 rounded-lg bg-white/15 border border-white/25 text-white placeholder-blue-300 text-sm outline-none focus:border-blue-300"
        />
        <button
          type="submit"
          className="w-full py-2.5 bg-orange-500 hover:bg-orange-600 rounded-lg text-sm font-semibold transition-colors"
        >
          सदस्य बनें — निःशुल्क
        </button>
      </form>
      <p className="text-blue-400 text-xs mt-3">कभी भी unsubscribe करें · spam नहीं</p>
    </div>
  );
}

// ── Editorial principles box ──────────────────────────────
function EditorialBox() {
  return (
    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5">
      <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mb-3">
        हमारे सिद्धांत
      </p>
      {[
        { icon: "👤", text: "व्यक्ति नहीं, विषय केंद्र में" },
        { icon: "📄", text: "आरोप नहीं, प्रमाण केंद्र में" },
        { icon: "🔍", text: "शोर नहीं, समझ केंद्र में" },
      ].map((p) => (
        <div key={p.text} className="flex items-start gap-3 mb-3 last:mb-0">
          <span className="text-lg">{p.icon}</span>
          <p className="text-sm text-slate-700 leading-relaxed">{p.text}</p>
        </div>
      ))}
      <Link
        href="/editorial-policy"
        className="mt-4 block text-center text-xs text-blue-600 hover:text-blue-800 font-medium"
      >
        संपादकीय नीति पढ़ें →
      </Link>
    </div>
  );
}

// ── Social channels box ───────────────────────────────────
function SocialChannelsBox() {
  const channels = [
    { name: "YouTube", sub: "वीडियो और Interview", color: "text-red-600 bg-red-50", href: "#", abbr: "YT" },
    { name: "Telegram", sub: "तुरंत अपडेट", color: "text-sky-600 bg-sky-50", href: "#", abbr: "TG" },
    { name: "X / Twitter", sub: "Analysis Thread", color: "text-slate-800 bg-slate-50", href: "#", abbr: "X" },
    { name: "WhatsApp", sub: "Daily Brief", color: "text-green-600 bg-green-50", href: "#", abbr: "WA" },
  ];
  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5">
      <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mb-4">
        हमसे जुड़ें
      </p>
      <div className="space-y-2.5">
        {channels.map((c) => (
          <a
            key={c.name}
            href={c.href}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 group"
          >
            <div className={`w-9 h-9 rounded-lg ${c.color} flex items-center justify-center text-xs font-bold flex-shrink-0`}>
              {c.abbr}
            </div>
            <div>
              <p className="text-sm font-medium text-slate-800 group-hover:text-blue-700 transition-colors">
                {c.name}
              </p>
              <p className="text-xs text-slate-400">{c.sub}</p>
            </div>
            <span className="ml-auto text-slate-300 group-hover:text-blue-400 transition-colors">→</span>
          </a>
        ))}
      </div>
    </div>
  );
}

// ── Homepage ──────────────────────────────────────────────
export default async function HomePage() {
  // Parallel data fetching
  const [latest, trending] = await Promise.allSettled([
    api.articles.latest(24),
    api.articles.trending(),
  ]);

  const latestArticles: Article[] =
    latest.status === "fulfilled" ? latest.value : MOCK_ARTICLES;

  const trendingArticles: Article[] =
    trending.status === "fulfilled" ? trending.value : MOCK_ARTICLES.slice(0, 5);

  // Split into sections
  const heroArticle = latestArticles[0];
  const heroSecondary = latestArticles.slice(1, 4);
  const analysisArticles = latestArticles.filter(
    (a) => a.contentType === "analysis" || a.contentType === "special_report"
  ).slice(0, 4);
  const factCheckArticles = latestArticles.filter(
    (a) => a.contentType === "fact_check"
  ).slice(0, 3);
  const interviewArticles = latestArticles.filter(
    (a) => a.contentType === "interview"
  ).slice(0, 2);
  const latestFeed = latestArticles.slice(4, 12);
  const opinionArticles = latestArticles.filter(
    (a) => a.contentType === "opinion"
  ).slice(0, 3);

  return (
    <>
      <Navbar />

      <main className="max-w-7xl mx-auto px-4">

        {/* ── HERO ──────────────────────────────────────── */}
        <section className="py-6">
          <div className="grid lg:grid-cols-3 gap-6">

            {/* Main hero */}
            <div className="lg:col-span-2">
              {heroArticle && <ArticleCardLarge article={heroArticle} />}
            </div>

            {/* Secondary stories */}
            <div className="space-y-5">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-widest">ताज़ा समाचार</span>
                <Link href="/latest" className="text-xs text-blue-600">सभी →</Link>
              </div>
              {heroSecondary.map((a) => (
                <ArticleCardMedium key={a.id} article={a} />
              ))}
            </div>
          </div>
        </section>

        {/* ── LATEST FEED + SIDEBAR ─────────────────────── */}
        <section className="py-6 border-t border-slate-100">
          <div className="grid lg:grid-cols-3 gap-8">

            {/* Left: Latest feed */}
            <div className="lg:col-span-2 space-y-8">

              {/* Analysis section */}
              {analysisArticles.length > 0 && (
                <div>
                  <SectionHead title="विशेष विश्लेषण" href="/category/analysis" icon="📊" />
                  <div className="grid sm:grid-cols-2 gap-5">
                    {analysisArticles.map((a) => (
                      <div key={a.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden card-lift">
                        <div className="h-36 bg-slate-100 relative">
                          {a.heroImageUrl ? (
                            <img src={a.heroImageUrl} alt={a.titleHi} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center">
                              <span className="text-blue-300 text-2xl">📊</span>
                            </div>
                          )}
                        </div>
                        <div className="p-4">
                          <div className="flex items-center gap-2 mb-2 text-xs text-slate-400">
                            <span className="font-medium text-blue-600">{a.category?.nameHi}</span>
                            <span>·</span>
                            <span>{a.readingTimeMins} मिनट</span>
                          </div>
                          <Link href={`/${a.category?.slug}/${a.slug}`}>
                            <h3 className="text-sm font-semibold text-slate-800 leading-snug hover:text-blue-700 transition-colors">
                              {a.titleHi}
                            </h3>
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Fact Check section */}
              {factCheckArticles.length > 0 && (
                <div>
                  <SectionHead title="तथ्य-जाँच" href="/fact-check" icon="✓" />
                  <div className="grid sm:grid-cols-3 gap-3">
                    {factCheckArticles.map((a, i) => (
                      <FactCheckCard
                        key={a.id}
                        article={a}
                        verdict={i === 0 ? "claim" : i === 1 ? "fact" : "misleading"}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Latest rolling feed */}
              <div>
                <SectionHead title="नवीनतम" href="/latest" icon="🕐" />
                <div className="bg-white rounded-xl border border-slate-200 divide-y divide-slate-50">
                  {latestFeed.map((a) => (
                    <div key={a.id} className="p-4">
                      <ArticleCardSmall article={a} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Opinion section */}
              {opinionArticles.length > 0 && (
                <div>
                  <SectionHead title="विचार / Opinion" href="/category/opinion" icon="💭" />
                  <div className="space-y-4">
                    {opinionArticles.map((a) => (
                      <Link
                        key={a.id}
                        href={`/${a.category?.slug}/${a.slug}`}
                        className="group block bg-white border border-slate-200 rounded-xl p-5 card-lift"
                      >
                        <div className="flex items-start gap-4">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-sm flex-shrink-0">
                            {a.authors?.[0]?.user.name[0] || "अ"}
                          </div>
                          <div>
                            <p className="text-xs text-slate-500 mb-1">{a.authors?.[0]?.user.name}</p>
                            <h3 className="text-sm font-semibold text-slate-800 leading-snug group-hover:text-blue-700 transition-colors">
                              {a.titleHi}
                            </h3>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* ── RIGHT SIDEBAR ──────────────────────── */}
            <aside className="space-y-6">

              {/* Trending */}
              <div>
                <SectionHead title="सर्वाधिक पठित" icon="🔥" />
                <div className="bg-white rounded-xl border border-slate-200">
                  {trendingArticles.slice(0, 5).map((a, i) => (
                    <Link
                      key={a.id}
                      href={`/${a.category?.slug}/${a.slug}`}
                      className="group flex items-start gap-3 p-4 border-b border-slate-50 last:border-0 hover:bg-slate-50 transition-colors"
                    >
                      <span className="text-2xl font-black text-slate-100 w-7 text-center flex-shrink-0 leading-none mt-0.5">
                        {i + 1}
                      </span>
                      <div>
                        <p className="text-xs text-blue-600 font-medium mb-0.5">{a.category?.nameHi}</p>
                        <h4 className="text-xs font-medium text-slate-700 leading-snug group-hover:text-blue-700 transition-colors line-clamp-2">
                          {a.titleHi}
                        </h4>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>

              {/* Interviews */}
              {interviewArticles.length > 0 && (
                <div>
                  <SectionHead title="विशेष संवाद" href="/category/samvad" icon="🎙" />
                  <div className="space-y-3">
                    {interviewArticles.map((a) => (
                      <Link
                        key={a.id}
                        href={`/${a.category?.slug}/${a.slug}`}
                        className="group block bg-gradient-to-br from-[#1a2744] to-[#1e3a8a] rounded-xl p-4 card-lift"
                      >
                        <span className="text-xs font-semibold text-blue-300">🎙 संवाद</span>
                        <h3 className="text-sm font-semibold text-white mt-1 leading-snug line-clamp-2 group-hover:text-blue-200 transition-colors">
                          {a.titleHi}
                        </h3>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              <NewsletterBox />
              <EditorialBox />
              <SocialChannelsBox />
            </aside>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}

// ── Mock data (used when API is unavailable) ──────────────
const MOCK_ARTICLES: Article[] = Array.from({ length: 12 }, (_, i) => ({
  id: `mock-${i}`,
  titleHi: [
    "संविधान की धारा 370: पाँच साल बाद — क्या बदला, क्या नहीं",
    "चुनावी बॉन्ड: सुप्रीम कोर्ट के फैसले के बाद नई जानकारियाँ",
    "RBI की नई मौद्रिक नीति: आम नागरिक पर क्या असर होगा?",
    "DNT समुदायों की ज़मीन पर अतिक्रमण — ग्राउंड रिपोर्ट",
    "समान नागरिक संहिता: कानूनी ढांचा और विवाद के असली बिंदु",
    "UN में भारत की स्थायी सदस्यता: ताजा स्थिति और बाधाएं",
    "विपक्ष का संसद में बड़ा आरोप — सरकार का क्या जवाब है?",
    "भारत की GDP वृद्धि दर: IMF और विश्व बैंक के अनुमानों का विश्लेषण",
    "मणिपुर — एक साल बाद: ज़मीनी सच्चाई क्या है?",
    "पूर्व CEC से संवाद: चुनाव सुधार की असल ज़रूरत क्या है?",
    "PMLA कानून: आसान भाषा में समझें क्या है और कैसे काम करता है",
    "बजट 2024 और रोज़गार: क्या सरकारी दावे सच हैं?",
  ][i],
  slug: `article-${i + 1}`,
  summary: "यह एक महत्वपूर्ण विषय है जिस पर गहन विश्लेषण आवश्यक है। पूरी जानकारी के लिए पढ़ें।",
  heroImageUrl: undefined,
  readingTimeMins: 8 + (i % 10),
  publishedAt: new Date(Date.now() - i * 3600000).toISOString(),
  viewCount: Math.floor(Math.random() * 8000) + 1000,
  contentType: ["article","analysis","fact_check","interview","ground_report","opinion","explainer"][i % 7],
  isAiAssisted: i % 3 === 0,
  category: {
    nameHi: ["राजनीति","अर्थव्यवस्था","समाज","संविधान","विश्व","तथ्य-जाँच"][i % 6],
    slug: ["politics","economy","society","constitution","world","fact-check"][i % 6],
  },
  authors: [{ user: { name: ["अजय सिंह","रमेश वर्मा","प्रिया दास","सुनीता शर्मा"][i % 4] } }],
  tags: [],
}));
