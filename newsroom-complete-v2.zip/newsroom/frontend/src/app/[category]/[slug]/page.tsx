import { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArticleBody } from "@/components/ArticleBody";
import { FactClaimBadge } from "@/components/FactClaimBadge";
import { RelatedArticles } from "@/components/RelatedArticles";
import { ShareButtons } from "@/components/ShareButtons";
import { AuthorCard } from "@/components/AuthorCard";
import { SourcesList } from "@/components/SourcesList";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

async function getArticle(slug: string) {
  try {
    const res = await fetch(`${API_URL}/v1/articles/${slug}`, {
      next: { revalidate: 300 }, // ISR: revalidate every 5 minutes
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

// ── Dynamic Metadata ──────────────────────────────────────
export async function generateMetadata({
  params,
}: {
  params: { category: string; slug: string };
}): Promise<Metadata> {
  const article = await getArticle(params.slug);
  if (!article) return { title: "Article not found" };

  return {
    title: article.seoTitle || article.titleHi,
    description: article.seoDescription || article.summary,
    keywords: article.seoKeywords || [],
    authors: article.authors?.map((a: { user: { name: string } }) => ({ name: a.user.name })),
    openGraph: {
      title: article.titleHi,
      description: article.summary,
      type: "article",
      publishedTime: article.publishedAt,
      modifiedTime: article.updatedAt,
      authors: article.authors?.map((a: { user: { name: string } }) => a.user.name),
      images: article.heroImageUrl
        ? [{ url: article.heroImageUrl, width: 1200, height: 630, alt: article.titleHi }]
        : [],
      section: article.category?.nameHi,
      tags: article.tags?.map((t: { tag: { nameHi: string } }) => t.tag.nameHi),
      locale: "hi_IN",
    },
    twitter: {
      card: "summary_large_image",
      title: article.titleHi,
      description: article.summary,
      images: article.heroImageUrl ? [article.heroImageUrl] : [],
    },
    alternates: {
      canonical: `https://gyanvarta.in/${params.category}/${params.slug}`,
    },
  };
}

// ── Article Page ──────────────────────────────────────────
export default async function ArticlePage({
  params,
}: {
  params: { category: string; slug: string };
}) {
  const article = await getArticle(params.slug);
  if (!article || article.status !== "published") notFound();

  // NewsArticle JSON-LD Schema
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    "headline": article.titleHi,
    "description": article.summary,
    "image": article.heroImageUrl ? [article.heroImageUrl] : [],
    "datePublished": article.publishedAt,
    "dateModified": article.updatedAt,
    "author": article.authors?.map((a: { user: { name: string } }) => ({
      "@type": "Person",
      "name": a.user.name,
    })),
    "publisher": {
      "@type": "NewsMediaOrganization",
      "name": "ज्ञानवार्ता",
      "logo": { "@type": "ImageObject", "url": "https://gyanvarta.in/logo.png" },
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": `https://gyanvarta.in/${params.category}/${params.slug}`,
    },
    "articleSection": article.category?.nameHi,
    "inLanguage": "hi",
    "isAccessibleForFree": true,
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }}
      />

      <article className="max-w-3xl mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="text-sm text-gray-500 mb-6 flex gap-2">
          <a href="/" className="hover:text-blue-600">मुख्य पृष्ठ</a>
          <span>/</span>
          <a href={`/${params.category}`} className="hover:text-blue-600">
            {article.category?.nameHi}
          </a>
          <span>/</span>
          <span className="text-gray-700 truncate max-w-xs">{article.titleHi}</span>
        </nav>

        {/* Category Badge */}
        <div className="mb-4">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200">
            {article.category?.nameHi}
          </span>
          {article.contentType === "fact_check" && (
            <span className="ml-2 inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-200">
              ✓ तथ्य-जाँच
            </span>
          )}
          {article.isSensitive && (
            <span className="ml-2 inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200">
              संवेदनशील विषय
            </span>
          )}
        </div>

        {/* Headline */}
        <h1 className="text-3xl md:text-4xl font-semibold text-gray-900 leading-tight mb-4">
          {article.titleHi}
        </h1>

        {article.subtitle && (
          <p className="text-xl text-gray-600 leading-relaxed mb-6">{article.subtitle}</p>
        )}

        {/* Meta */}
        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-6 pb-6 border-b">
          {article.authors?.map((a: { user: { name: string; id: string } }) => (
            <span key={a.user.id} className="font-medium text-gray-700">
              {a.user.name}
            </span>
          ))}
          <span>
            {article.publishedAt
              ? new Date(article.publishedAt).toLocaleDateString("hi-IN", {
                  year: "numeric", month: "long", day: "numeric",
                })
              : ""}
          </span>
          {article.updatedAt && article.updatedAt !== article.publishedAt && (
            <span className="text-amber-600">
              अपडेट: {new Date(article.updatedAt).toLocaleDateString("hi-IN")}
            </span>
          )}
          {article.readingTimeMins && (
            <span>{article.readingTimeMins} मिनट पठन</span>
          )}
          {article.isAiAssisted && (
            <span className="text-purple-600 text-xs border border-purple-200 rounded px-2 py-0.5">
              AI-सहायता
            </span>
          )}
        </div>

        {/* Hero Image */}
        {article.heroImageUrl && (
          <figure className="mb-8">
            <img
              src={article.heroImageUrl}
              alt={article.heroImageCaption || article.titleHi}
              className="w-full rounded-xl object-cover max-h-96"
            />
            {article.heroImageCaption && (
              <figcaption className="text-sm text-gray-500 mt-2 text-center">
                {article.heroImageCaption}
              </figcaption>
            )}
          </figure>
        )}

        {/* Summary Box */}
        {article.summary && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-5 mb-8">
            <p className="text-sm font-medium text-blue-700 mb-2">संक्षेप</p>
            <p className="text-gray-700 leading-relaxed">{article.summary}</p>
          </div>
        )}

        {/* Claims with Classification */}
        {article.claims && article.claims.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-800 mb-3">
              दावे और तथ्य-वर्गीकरण
            </h2>
            <div className="space-y-3">
              {article.claims.map((claim: { id: string; claimText: string; classification: string; madeBy?: string; isVerified: boolean }) => (
                <FactClaimBadge key={claim.id} claim={claim} />
              ))}
            </div>
          </div>
        )}

        {/* Article Body */}
        <ArticleBody content={article.bodyHtml || article.body} />

        {/* AI Disclosure */}
        {article.isAiAssisted && (
          <div className="mt-8 bg-purple-50 border border-purple-200 rounded-xl p-4 text-sm text-purple-700">
            <strong>AI प्रकटीकरण:</strong> {article.aiDisclosureNote ||
              "यह लेख AI-सहायता से तैयार किया गया है और मानव संपादक द्वारा समीक्षित है।"}
          </div>
        )}

        {/* Sources */}
        {article.sources && article.sources.length > 0 && (
          <SourcesList sources={article.sources} />
        )}

        {/* Corrections */}
        {article.corrections && article.corrections.filter((c: { isPublished: boolean }) => c.isPublished).length > 0 && (
          <div className="mt-8 border border-amber-200 rounded-xl p-4 bg-amber-50">
            <h3 className="font-semibold text-amber-800 mb-2">सुधार</h3>
            {article.corrections
              .filter((c: { isPublished: boolean }) => c.isPublished)
              .map((c: { id: string; publishedAt: string; correction: string }) => (
                <div key={c.id} className="text-sm text-amber-700 mb-2">
                  <span className="text-amber-500">
                    {new Date(c.publishedAt).toLocaleDateString("hi-IN")}:
                  </span>{" "}
                  {c.correction}
                </div>
              ))}
          </div>
        )}

        {/* Share */}
        <ShareButtons
          url={`https://gyanvarta.in/${params.category}/${params.slug}`}
          title={article.titleHi}
        />

        {/* Author Cards */}
        <div className="mt-12 grid gap-4">
          {article.authors?.map((a: { user: { id: string; name: string; bio?: string; avatarUrl?: string } }) => (
            <AuthorCard key={a.user.id} author={a.user} />
          ))}
        </div>
      </article>

      {/* Related Articles */}
      {article.category && (
        <div className="max-w-3xl mx-auto px-4 pb-12">
          <RelatedArticles
            categoryId={article.categoryId}
            currentArticleId={article.id}
          />
        </div>
      )}
    </>
  );
}

// ── Static Generation ─────────────────────────────────────
export async function generateStaticParams() {
  // Pre-generate top articles at build time
  try {
    const res = await fetch(`${API_URL}/v1/articles?limit=100`);
    const data = await res.json();
    return (data.articles || []).map((a: { categoryId: string; slug: string }) => ({
      category: a.categoryId,
      slug: a.slug,
    }));
  } catch {
    return [];
  }
}
