import type { Metadata, Viewport } from "next";
import { Noto_Sans_Devanagari, Noto_Serif_Devanagari } from "next/font/google";
import "./globals.css";

const notoSans = Noto_Sans_Devanagari({
  subsets: ["devanagari", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-sans",
  display: "swap",
});

const notoSerif = Noto_Serif_Devanagari({
  subsets: ["devanagari"],
  weight: ["400", "700"],
  variable: "--font-serif",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://gyanvarta.in"),
  title: {
    default: "ज्ञानवार्ता — हिंदी समाचार विश्लेषण",
    template: "%s | ज्ञानवार्ता",
  },
  description: "गहन विश्लेषण, तथ्य-जाँच और शोध। आज की खबर को कल के ज्ञान में बदलना।",
  keywords: ["हिंदी समाचार", "विश्लेषण", "तथ्य जाँच", "भारत", "राजनीति"],
  authors: [{ name: "ज्ञानवार्ता", url: "https://gyanvarta.in" }],
  creator: "GBSBFORYOU Publications",
  publisher: "GBSBFORYOU Publications",
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-snippet": -1, "max-image-preview": "large" },
  },
  openGraph: {
    type: "website",
    locale: "hi_IN",
    url: "https://gyanvarta.in",
    siteName: "ज्ञानवार्ता",
    title: "ज्ञानवार्ता — हिंदी समाचार विश्लेषण",
    description: "गहन विश्लेषण, तथ्य-जाँच और शोध। आज की खबर को कल के ज्ञान में बदलना।",
    images: [{ url: "/og-default.jpg", width: 1200, height: 630, alt: "ज्ञानवार्ता" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "ज्ञानवार्ता",
    description: "गहन विश्लेषण, तथ्य-जाँच और शोध",
    creator: "@gyanvarta",
    images: ["/og-default.jpg"],
  },
  alternates: {
    canonical: "https://gyanvarta.in",
    types: { "application/rss+xml": "https://gyanvarta.in/feed.xml" },
  },
  verification: {
    google: process.env.NEXT_PUBLIC_GOOGLE_VERIFY || "",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#1a2744",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="hi" dir="ltr" className={`${notoSans.variable} ${notoSerif.variable}`}>
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/icon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/manifest.json" />
        {/* Organization Schema */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "NewsMediaOrganization",
              "name": "ज्ञानवार्ता",
              "url": "https://gyanvarta.in",
              "logo": { "@type": "ImageObject", "url": "https://gyanvarta.in/logo.png" },
              "sameAs": [
                "https://youtube.com/@gyanvarta",
                "https://x.com/gyanvarta",
                "https://facebook.com/gyanvarta",
              ],
              "publishingPrinciples": "https://gyanvarta.in/editorial-policy",
              "actionableFeedbackPolicy": "https://gyanvarta.in/corrections",
              "masthead": "https://gyanvarta.in/about",
              "inLanguage": "hi",
            }),
          }}
        />
      </head>
      <body className={`${notoSans.className} antialiased`}>
        {children}
      </body>
    </html>
  );
}
