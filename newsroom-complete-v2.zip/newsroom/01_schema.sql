-- ============================================================
-- ज्ञानवार्ता — Hindi News Platform
-- PostgreSQL Database Schema v1.0
-- GBSBFORYOU Publications
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- Hindi full-text search support

-- ============================================================
-- 1. USERS & ACCESS CONTROL
-- ============================================================

CREATE TYPE user_role AS ENUM (
  'super_admin','admin','chief_editor','editor',
  'reporter','researcher','social_editor',
  'video_editor','author','reviewer','advertiser','analytics'
);

CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role          user_role NOT NULL DEFAULT 'author',
  avatar_url    TEXT,
  bio           TEXT,
  is_active     BOOLEAN DEFAULT true,
  two_fa_secret TEXT,
  two_fa_enabled BOOLEAN DEFAULT false,
  last_login_at TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE api_keys (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  name       VARCHAR(100) NOT NULL,
  key_hash   TEXT NOT NULL,
  last_used  TIMESTAMPTZ,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE audit_logs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  action      VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50),
  entity_id   UUID,
  old_data    JSONB,
  new_data    JSONB,
  ip_address  INET,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 2. CONTENT MANAGEMENT
-- ============================================================

CREATE TYPE content_status AS ENUM (
  'draft','ai_generated','editor_review','fact_check_pending',
  'approved','scheduled','published','correction_required',
  'sensitive_review','archived','rejected'
);

CREATE TYPE content_type AS ENUM (
  'article','analysis','interview','fact_check',
  'ground_report','explainer','opinion','special_report','research'
);

CREATE TABLE categories (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name_hi     VARCHAR(100) NOT NULL,
  name_en     VARCHAR(100),
  slug        VARCHAR(120) UNIQUE NOT NULL,
  parent_id   UUID REFERENCES categories(id),
  description TEXT,
  sort_order  INT DEFAULT 0,
  is_active   BOOLEAN DEFAULT true,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE tags (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name_hi    VARCHAR(80) NOT NULL,
  name_en    VARCHAR(80),
  slug       VARCHAR(100) UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE articles (
  id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title_hi           TEXT NOT NULL,
  title_en           TEXT,
  slug               VARCHAR(300) UNIQUE NOT NULL,
  subtitle           TEXT,
  summary            TEXT,
  body               TEXT NOT NULL,
  body_html          TEXT,
  content_type       content_type DEFAULT 'article',
  status             content_status DEFAULT 'draft',
  category_id        UUID REFERENCES categories(id),
  hero_image_url     TEXT,
  hero_image_caption TEXT,
  reading_time_mins  INT,
  is_sensitive       BOOLEAN DEFAULT false,
  is_ai_assisted     BOOLEAN DEFAULT false,
  ai_disclosure_note TEXT,
  published_at       TIMESTAMPTZ,
  scheduled_at       TIMESTAMPTZ,
  created_by         UUID REFERENCES users(id),
  updated_by         UUID REFERENCES users(id),
  approved_by        UUID REFERENCES users(id),
  approved_at        TIMESTAMPTZ,
  view_count         BIGINT DEFAULT 0,
  share_count        INT DEFAULT 0,
  seo_title          TEXT,
  seo_description    TEXT,
  seo_keywords       TEXT[],
  og_image_url       TEXT,
  schema_markup      JSONB,
  created_at         TIMESTAMPTZ DEFAULT NOW(),
  updated_at         TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_articles_slug ON articles(slug);
CREATE INDEX idx_articles_status ON articles(status);
CREATE INDEX idx_articles_published ON articles(published_at DESC) WHERE status = 'published';
CREATE INDEX idx_articles_category ON articles(category_id);
CREATE INDEX idx_articles_title_trgm ON articles USING gin(title_hi gin_trgm_ops);

CREATE TABLE article_authors (
  article_id UUID REFERENCES articles(id) ON DELETE CASCADE,
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  role       VARCHAR(50) DEFAULT 'author',
  PRIMARY KEY (article_id, user_id)
);

CREATE TABLE article_tags (
  article_id UUID REFERENCES articles(id) ON DELETE CASCADE,
  tag_id     UUID REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (article_id, tag_id)
);

CREATE TABLE article_revisions (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  article_id   UUID REFERENCES articles(id) ON DELETE CASCADE,
  title_hi     TEXT,
  body         TEXT,
  changed_by   UUID REFERENCES users(id),
  change_note  TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE corrections (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  article_id   UUID REFERENCES articles(id) ON DELETE CASCADE,
  correction   TEXT NOT NULL,
  original     TEXT,
  corrected_by UUID REFERENCES users(id),
  is_published BOOLEAN DEFAULT false,
  published_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 3. FACT CHECK & SOURCE SYSTEM
-- ============================================================

CREATE TYPE source_type AS ENUM (
  'government','court','parliament','official_document',
  'press_release','interview','research_paper','academic',
  'news_organisation','field_report','social_media','other'
);

CREATE TYPE reliability_status AS ENUM (
  'high','medium','low','unverified','disputed'
);

CREATE TYPE claim_classification AS ENUM (
  'fact','claim','official_statement','documented_evidence',
  'unverified','analysis','opinion'
);

CREATE TABLE sources (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name                VARCHAR(200) NOT NULL,
  source_type         source_type NOT NULL,
  url                 TEXT,
  document_url        TEXT,
  publication_date    DATE,
  author_name         VARCHAR(150),
  institution         VARCHAR(200),
  reliability_status  reliability_status DEFAULT 'unverified',
  topic               VARCHAR(200),
  evidence_type       VARCHAR(100),
  verification_status VARCHAR(50) DEFAULT 'pending',
  notes               TEXT,
  added_by            UUID REFERENCES users(id),
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE claims (
  id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  article_id           UUID REFERENCES articles(id) ON DELETE CASCADE,
  claim_text           TEXT NOT NULL,
  classification       claim_classification NOT NULL,
  source_id            UUID REFERENCES sources(id),
  made_by              VARCHAR(200),
  made_by_entity_id    UUID,
  context              TEXT,
  is_verified          BOOLEAN DEFAULT false,
  verification_note    TEXT,
  verified_by          UUID REFERENCES users(id),
  verified_at          TIMESTAMPTZ,
  created_at           TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE article_sources (
  article_id  UUID REFERENCES articles(id) ON DELETE CASCADE,
  source_id   UUID REFERENCES sources(id) ON DELETE CASCADE,
  usage_note  TEXT,
  sort_order  INT DEFAULT 0,
  PRIMARY KEY (article_id, source_id)
);

CREATE TABLE fact_checks (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  claim_id        UUID REFERENCES claims(id),
  article_id      UUID REFERENCES articles(id),
  verdict         VARCHAR(50) NOT NULL,
  verdict_detail  TEXT NOT NULL,
  evidence        JSONB,
  fact_checker_id UUID REFERENCES users(id),
  reviewed_by     UUID REFERENCES users(id),
  is_published    BOOLEAN DEFAULT false,
  published_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 4. KNOWLEDGE CORE
-- ============================================================

CREATE TYPE entity_type AS ENUM (
  'person','organization','government_dept','political_party',
  'institution','place','event','document','policy',
  'law','court_case'
);

CREATE TABLE knowledge_entities (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  entity_type  entity_type NOT NULL,
  name_hi      VARCHAR(200) NOT NULL,
  name_en      VARCHAR(200),
  slug         VARCHAR(220) UNIQUE NOT NULL,
  description  TEXT,
  metadata     JSONB DEFAULT '{}',
  image_url    TEXT,
  is_verified  BOOLEAN DEFAULT false,
  created_by   UUID REFERENCES users(id),
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_entity_type ON knowledge_entities(entity_type);
CREATE INDEX idx_entity_name_trgm ON knowledge_entities USING gin(name_hi gin_trgm_ops);

CREATE TABLE entity_relationships (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  from_entity_id  UUID REFERENCES knowledge_entities(id) ON DELETE CASCADE,
  to_entity_id    UUID REFERENCES knowledge_entities(id) ON DELETE CASCADE,
  relation_type   VARCHAR(100) NOT NULL,
  description     TEXT,
  valid_from      DATE,
  valid_to        DATE,
  source_id       UUID REFERENCES sources(id),
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE article_entities (
  article_id UUID REFERENCES articles(id) ON DELETE CASCADE,
  entity_id  UUID REFERENCES knowledge_entities(id) ON DELETE CASCADE,
  role       VARCHAR(100),
  PRIMARY KEY (article_id, entity_id)
);

-- ============================================================
-- 5. VIDEO SYSTEM
-- ============================================================

CREATE TYPE video_status AS ENUM (
  'uploading','processing','draft','review','approved','published','archived'
);

CREATE TABLE programs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name_hi     VARCHAR(200) NOT NULL,
  slug        VARCHAR(220) UNIQUE NOT NULL,
  description TEXT,
  host_id     UUID REFERENCES users(id),
  category_id UUID REFERENCES categories(id),
  thumbnail   TEXT,
  is_active   BOOLEAN DEFAULT true,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE videos (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title_hi          TEXT NOT NULL,
  title_en          TEXT,
  slug              VARCHAR(300) UNIQUE NOT NULL,
  description       TEXT,
  program_id        UUID REFERENCES programs(id),
  article_id        UUID REFERENCES articles(id),
  status            video_status DEFAULT 'draft',
  duration_secs     INT,
  thumbnail_url     TEXT,
  video_url         TEXT,
  cdn_url           TEXT,
  youtube_id        TEXT,
  youtube_url       TEXT,
  view_count        BIGINT DEFAULT 0,
  is_live           BOOLEAN DEFAULT false,
  live_stream_url   TEXT,
  uploaded_by       UUID REFERENCES users(id),
  published_at      TIMESTAMPTZ,
  seo_title         TEXT,
  seo_description   TEXT,
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE video_clips (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  video_id    UUID REFERENCES videos(id) ON DELETE CASCADE,
  title_hi    TEXT NOT NULL,
  clip_url    TEXT,
  start_secs  INT NOT NULL,
  end_secs    INT NOT NULL,
  topic       TEXT,
  is_short    BOOLEAN DEFAULT false,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE transcripts (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  video_id    UUID REFERENCES videos(id) ON DELETE CASCADE,
  article_id  UUID REFERENCES articles(id),
  content     TEXT NOT NULL,
  language    VARCHAR(10) DEFAULT 'hi',
  is_ai_generated BOOLEAN DEFAULT false,
  reviewed_by UUID REFERENCES users(id),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 6. SOCIAL MEDIA SYSTEM
-- ============================================================

CREATE TYPE platform_name AS ENUM (
  'youtube','facebook','instagram','x_twitter','threads',
  'telegram','whatsapp_channel','linkedin'
);

CREATE TYPE post_status AS ENUM (
  'draft','ai_generated','editor_review','approved',
  'scheduled','published','failed','correction_required','archived'
);

CREATE TYPE content_format AS ENUM (
  'breaking_update','explainer','quote_card','fact_card',
  'document_highlight','video_clip','interview_clip','timeline',
  'data_graphic','poll','question','carousel','short_analysis',
  'long_analysis','behind_story','editors_note','correction'
);

CREATE TABLE social_accounts (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  platform        platform_name NOT NULL,
  account_name    VARCHAR(150) NOT NULL,
  username        VARCHAR(100),
  account_id      TEXT,
  access_token    TEXT,
  token_expires   TIMESTAMPTZ,
  refresh_token   TEXT,
  is_active       BOOLEAN DEFAULT true,
  profile_url     TEXT,
  bio             TEXT,
  followers_count INT DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE social_posts (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  article_id      UUID REFERENCES articles(id) ON DELETE SET NULL,
  video_id        UUID REFERENCES videos(id) ON DELETE SET NULL,
  account_id      UUID REFERENCES social_accounts(id) ON DELETE CASCADE,
  platform        platform_name NOT NULL,
  content         TEXT NOT NULL,
  format          content_format,
  media_urls      TEXT[],
  status          post_status DEFAULT 'draft',
  is_ai_generated BOOLEAN DEFAULT false,
  scheduled_at    TIMESTAMPTZ,
  published_at    TIMESTAMPTZ,
  platform_post_id TEXT,
  platform_url    TEXT,
  created_by      UUID REFERENCES users(id),
  approved_by     UUID REFERENCES users(id),
  approved_at     TIMESTAMPTZ,
  error_message   TEXT,
  reach           INT DEFAULT 0,
  impressions     INT DEFAULT 0,
  engagements     INT DEFAULT 0,
  clicks          INT DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_social_posts_scheduled ON social_posts(scheduled_at) WHERE status = 'scheduled';
CREATE INDEX idx_social_posts_platform ON social_posts(platform, status);

-- ============================================================
-- 7. ANALYTICS
-- ============================================================

CREATE TABLE page_views (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  article_id   UUID REFERENCES articles(id) ON DELETE CASCADE,
  session_id   VARCHAR(100),
  referrer     TEXT,
  utm_source   VARCHAR(100),
  utm_medium   VARCHAR(100),
  utm_campaign VARCHAR(100),
  country      VARCHAR(5),
  device_type  VARCHAR(20),
  read_secs    INT DEFAULT 0,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_pageviews_article ON page_views(article_id, created_at DESC);
CREATE INDEX idx_pageviews_date ON page_views(created_at DESC);

CREATE TABLE weekly_analytics_reports (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  week_start      DATE NOT NULL,
  week_end        DATE NOT NULL,
  total_pageviews BIGINT,
  unique_visitors BIGINT,
  top_articles    JSONB,
  top_topics      JSONB,
  social_summary  JSONB,
  video_summary   JSONB,
  ai_insights     TEXT,
  editorial_recs  TEXT,
  social_recs     TEXT,
  video_recs      TEXT,
  generated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 8. NEWSLETTER
-- ============================================================

CREATE TABLE newsletter_subscribers (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email           VARCHAR(150) UNIQUE NOT NULL,
  name            VARCHAR(100),
  subscription_types TEXT[] DEFAULT ARRAY['daily_brief'],
  is_active       BOOLEAN DEFAULT true,
  confirmed       BOOLEAN DEFAULT false,
  confirm_token   TEXT,
  subscribed_at   TIMESTAMPTZ DEFAULT NOW(),
  unsubscribed_at TIMESTAMPTZ
);

CREATE TABLE newsletters (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  subject      TEXT NOT NULL,
  body_html    TEXT NOT NULL,
  body_text    TEXT,
  nl_type      VARCHAR(50) DEFAULT 'daily_brief',
  send_count   INT DEFAULT 0,
  open_count   INT DEFAULT 0,
  click_count  INT DEFAULT 0,
  scheduled_at TIMESTAMPTZ,
  sent_at      TIMESTAMPTZ,
  created_by   UUID REFERENCES users(id),
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 9. RESEARCH & BOOKS
-- ============================================================

CREATE TABLE research_projects (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title_hi    TEXT NOT NULL,
  description TEXT,
  lead_id     UUID REFERENCES users(id),
  status      VARCHAR(50) DEFAULT 'active',
  started_at  DATE,
  completed_at DATE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE research_notes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id  UUID REFERENCES research_projects(id) ON DELETE CASCADE,
  content     TEXT NOT NULL,
  note_type   VARCHAR(50),
  source_id   UUID REFERENCES sources(id),
  created_by  UUID REFERENCES users(id),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE books (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title_hi    TEXT NOT NULL,
  title_en    TEXT,
  slug        VARCHAR(300) UNIQUE NOT NULL,
  description TEXT,
  author_id   UUID REFERENCES users(id),
  cover_url   TEXT,
  isbn        VARCHAR(20),
  publisher   VARCHAR(150) DEFAULT 'GBSBFORYOU Publications',
  status      VARCHAR(50) DEFAULT 'draft',
  published_at DATE,
  kdp_url     TEXT,
  payhip_url  TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE book_chapters (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  book_id     UUID REFERENCES books(id) ON DELETE CASCADE,
  title_hi    TEXT NOT NULL,
  content     TEXT,
  sort_order  INT DEFAULT 0,
  article_id  UUID REFERENCES articles(id),
  interview_id UUID REFERENCES videos(id),
  research_project_id UUID REFERENCES research_projects(id),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 10. MONETIZATION
-- ============================================================

CREATE TABLE sponsors (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(200) NOT NULL,
  logo_url    TEXT,
  website     TEXT,
  contact     VARCHAR(200),
  is_active   BOOLEAN DEFAULT true,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE advertisements (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sponsor_id   UUID REFERENCES sponsors(id),
  title        VARCHAR(200),
  ad_type      VARCHAR(50),
  placement    VARCHAR(100),
  image_url    TEXT,
  click_url    TEXT,
  is_active    BOOLEAN DEFAULT true,
  is_labeled   BOOLEAN DEFAULT true,
  starts_at    TIMESTAMPTZ,
  ends_at      TIMESTAMPTZ,
  impression_count BIGINT DEFAULT 0,
  click_count  INT DEFAULT 0,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE memberships (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id) ON DELETE CASCADE,
  plan          VARCHAR(50) NOT NULL,
  started_at    TIMESTAMPTZ DEFAULT NOW(),
  expires_at    TIMESTAMPTZ,
  is_active     BOOLEAN DEFAULT true,
  payment_ref   TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- UPDATED_AT TRIGGERS
-- ============================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_articles_updated    BEFORE UPDATE ON articles    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_users_updated       BEFORE UPDATE ON users       FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_sources_updated     BEFORE UPDATE ON sources     FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_social_posts_upd    BEFORE UPDATE ON social_posts FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_social_accounts_upd BEFORE UPDATE ON social_accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_knowledge_upd       BEFORE UPDATE ON knowledge_entities FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_videos_updated      BEFORE UPDATE ON videos      FOR EACH ROW EXECUTE FUNCTION update_updated_at();

