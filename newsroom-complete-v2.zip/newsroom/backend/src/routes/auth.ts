import { Router, Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { authenticator } from "otplib";
import { PrismaClient } from "@prisma/client";
import { z } from "zod";
import { authenticate, AuthRequest } from "../middleware/auth";

const router = Router();
const prisma = new PrismaClient();

const JWT_SECRET = process.env.JWT_SECRET!;
const JWT_REFRESH = process.env.JWT_REFRESH_SECRET!;
const JWT_EXPIRES = "15m";
const REFRESH_EXPIRES = "7d";

function generateTokens(user: { id: string; email: string; role: string; name: string }) {
  const access = jwt.sign(
    { id: user.id, email: user.email, role: user.role, name: user.name },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES }
  );
  const refresh = jwt.sign({ id: user.id }, JWT_REFRESH, { expiresIn: REFRESH_EXPIRES });
  return { access, refresh };
}

// ── Login ─────────────────────────────────────────────────
router.post("/login", async (req: Request, res: Response) => {
  const schema = z.object({
    email: z.string().email(),
    password: z.string().min(8),
    totpCode: z.string().optional(),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid input", details: parsed.error.errors });
  }

  const { email, password, totpCode } = parsed.data;

  try {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !user.isActive) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const passwordMatch = await bcrypt.compare(password, user.passwordHash);
    if (!passwordMatch) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    // 2FA check for privileged roles
    const privilegedRoles = ["super_admin", "admin", "chief_editor", "editor"];
    if (user.twoFaEnabled && privilegedRoles.includes(user.role)) {
      if (!totpCode) {
        return res.status(200).json({ requires2FA: true, message: "2FA code required" });
      }
      const valid = authenticator.verify({
        token: totpCode,
        secret: user.twoFaSecret!,
      });
      if (!valid) {
        return res.status(401).json({ error: "Invalid 2FA code" });
      }
    }

    // Update last login
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    const tokens = generateTokens(user);

    res.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        avatarUrl: user.avatarUrl,
      },
      accessToken: tokens.access,
      refreshToken: tokens.refresh,
    });
  } catch (err) {
    res.status(500).json({ error: "Login failed" });
  }
});

// ── Refresh Token ─────────────────────────────────────────
router.post("/refresh", async (req: Request, res: Response) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ error: "Refresh token required" });

  try {
    const decoded = jwt.verify(refreshToken, JWT_REFRESH) as { id: string };
    const user = await prisma.user.findUnique({ where: { id: decoded.id } });

    if (!user || !user.isActive) {
      return res.status(401).json({ error: "Invalid refresh token" });
    }

    const tokens = generateTokens(user);
    res.json({ accessToken: tokens.access, refreshToken: tokens.refresh });
  } catch {
    res.status(401).json({ error: "Invalid or expired refresh token" });
  }
});

// ── Setup 2FA ─────────────────────────────────────────────
router.post("/setup-2fa", authenticate, async (req: AuthRequest, res: Response) => {
  const secret = authenticator.generateSecret();
  const otpauth = authenticator.keyuri(
    req.user!.email,
    "ज्ञानवार्ता CMS",
    secret
  );

  await prisma.user.update({
    where: { id: req.user!.id },
    data: { twoFaSecret: secret },
  });

  res.json({ secret, otpauth, message: "QR code को scan करें और code verify करें" });
});

// ── Verify & Enable 2FA ───────────────────────────────────
router.post("/verify-2fa", authenticate, async (req: AuthRequest, res: Response) => {
  const { code } = req.body;
  const user = await prisma.user.findUnique({ where: { id: req.user!.id } });

  if (!user?.twoFaSecret) {
    return res.status(400).json({ error: "First setup 2FA" });
  }

  const valid = authenticator.verify({ token: code, secret: user.twoFaSecret });
  if (!valid) return res.status(400).json({ error: "Invalid code" });

  await prisma.user.update({
    where: { id: user.id },
    data: { twoFaEnabled: true },
  });

  res.json({ message: "2FA successfully enabled" });
});

// ── Get Current User ──────────────────────────────────────
router.get("/me", authenticate, async (req: AuthRequest, res: Response) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    select: {
      id: true, name: true, email: true, role: true,
      avatarUrl: true, bio: true, twoFaEnabled: true,
      lastLoginAt: true, createdAt: true,
    },
  });
  res.json(user);
});

// ── Change Password ───────────────────────────────────────
router.post("/change-password", authenticate, async (req: AuthRequest, res: Response) => {
  const schema = z.object({
    currentPassword: z.string(),
    newPassword: z.string().min(8),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
  if (!user) return res.status(404).json({ error: "User not found" });

  const match = await bcrypt.compare(parsed.data.currentPassword, user.passwordHash);
  if (!match) return res.status(400).json({ error: "Current password incorrect" });

  const newHash = await bcrypt.hash(parsed.data.newPassword, 12);
  await prisma.user.update({
    where: { id: user.id },
    data: { passwordHash: newHash },
  });

  res.json({ message: "Password updated successfully" });
});

export { router as authRouter };
